

<?php
include('header.php');
include('sidebar.php');

require_once("connect.php");
if(!empty($_POST["save_record"])) {
	$pdo_statement=$db_con->prepare("update kwerekwe set taxstatus='" . $_POST[ 'status' ]. "'  where shopid=" . $_GET["owner"]);
	$result = $pdo_statement->execute();
	if($result) {
		echo "<script type= 'text/javascript'>alert('Update Successfully');
        window.location.href='viewkwerekwe.php';
        </script>";
	}
}
    $pdo_statement = $db_con->prepare("SELECT * FROM kwerekwe where shopid = " . $_GET["owner"]);
    $pdo_statement->execute();
    $result = $pdo_statement->fetchAll();
?>
<html>
<head>
<title>EasyFix</title>

</head>

<?php
//include ("gownernav.php");
?>
<!-- <div style="margin:20px 0px;text-align:right;"><a href="index.php" class="button_link">Back to List</a></div> -->
<section id="main-content"><body class="bg-primary1 " >

        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    
                                    <div class="card-body">
                                    <form name="frmAdd" action="" method="POST" style="margin-top:15%">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Update Shop</h3></div>
                                            <div class="form-row">
                                                <div class="col-md-6">
                                                    <div class="form-group"><label class="small mb-1" for="inputFirstName">Shop Name</label><input class="form-control py-4" name="gname" type="text"  value="<?php echo $result[0]['name10']; ?>"/><required></div>
                                                </div>
												<div class="col-md-6">
                                                    <div class="form-group"><label class="small mb-1" for="inputFirstName">Shop type</label><input class="form-control py-4" name="address" type="text"  value="<?php echo $result[0]['shop']; ?>" /></div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group"><label class="small mb-1" for="inputFirstName">Tax status</label><input class="form-control py-4" name="status" type="text" value="<?php echo $result[0]['taxstatus']; ?>"/></div>
                                                </div>
												
												
												
</div>
                   
                                                
  
<div class="form-row"  >
<div class="col-md-6">
                                                    <button name="save_record" type="submit" value="Save" class="btn btn-primary btn-block">Save Data</a></div>
													<div class="col-md-6">
													<a class="btn btn-primary btn-block" href="index.php">Cancel</a>
													</div>
													</div>
  
  
 
  </form>
</div>
</body>
</html>