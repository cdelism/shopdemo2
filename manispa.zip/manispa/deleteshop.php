<?php
require_once("connect.php");
$pdo_statement=$db_con->prepare("delete from kwerekwe where shopid=" . $_GET['owner']);
$pdo_statement->execute();
echo"<script>
        alert('You have succesfull Delete Shop Record');
        window.location.href='viewkwerekwe.php';
        </script> ";

?>
