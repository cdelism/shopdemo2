var osmlayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

var overlays = {
    "Threat toward Drainage blockage":threats,
    "Flooding Impact of Drainage Blockage ":impact,
    "Blockage material":blockages
   }; 
var basemaps = {
    "OpenStreetMap":osmlayer
};

L.control.layers(overlays,basemaps,{position:'topright'}).addTo(map);