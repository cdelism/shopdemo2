  <!--sidebar start-->
  <aside>
    <div id="sidebar" class="nav-collapse ">
      <!-- sidebar menu start-->
      <ul class="sidebar-menu">
        <li class="active">
          <a class="" href="index.php">
                        <i class="icon_house_alt"></i>
                        <span>Dashboard</span>
                    </a>
        </li>
        <li class="sub-menu">
          <a href="javascript:;" class="">
                        <i class="icon_document_alt"></i>
                        <span>Shehias</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
          <ul class="sub">
            <li><a class="" href="shopdemo/index.html"> kwerekwe</a></li>
            <li><a class="" href="form_validation.html">Magomeni</a></li>
          </ul>
        </li>
        <li class="sub-menu">
          <a href="javascript:;" class="">
                        <i class="icon_desktop"></i>
                        <span>UI Fitures</span>
                        <span class="menu-arrow arrow_carrot-right"></span>
                    </a>
          <ul class="sub">
            <li><a class="" href="general.html">Elements</a></li>
            <li><a class="" href="buttons.html">Buttons</a></li>
            <li><a class="" href="grids.html">Grids</a></li>
          </ul>
        </li>
       
      </ul>
      <!-- sidebar menu end-->
    </div>
  </aside>
  <!--sidebar end-->