<?php
include('header.php');
include('sidebar.php');
?>
<body>  <section id="main-content">
      <section class="wrapper">
        <div class="container">
        <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search by shop number.." title="Type in a name">

            <h3> Available sho recods</h3>
<div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
          Available Shop In kwerekwe
              </header>
              
   <table class="table table-striped table-advance table-hover" id="myTable">
                <tbody>
	<tr >
    <th style="font-style:italic; font-size:15px">ShopNumber</th>
		<th style="font-style:italic; font-size:15px">ShopName</th>
        <th style="font-style:italic; font-size:15px"> ShopTypr</th>
       <th style="font-style:italic; font-size:15px">TaxStatus</th>
     
     <th style="font-style:italic; font-size:15px"> Action</th>
        
	</tr>


	<?php
		include('connect.php');
		$result = $db_con->prepare("SELECT * FROM kwerekwe");
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
	?>

		<tr style colour ="red">
        <td style="text-align:center; word-break:break-all; width:200px;"> <?php echo $row ['shopid']; ?></td>
								<td style="text-align:center; word-break:break-all; width:200px;"> <?php echo $row ['name10']; ?></td>
								<td style="text-align:center; word-break:break-all; width:200px;"> <?php echo $row ['shop']; ?></td>
								<td style="text-align:center; word-break:break-all; width:200px;"> <?php echo $row ['taxstatus']; ?></td>
                               
							
                                    <td>
                                    <div class="btn-group">
                        <a class="btn btn-primary" href='updateshop.php?owner=<?php echo $row['shopid']; ?>'><i class="icon_plus_alt2"></i></a>
                        <a class="btn btn-success" href='map.php?owner=<?php echo $row['shopid']; ?>'><i class="fa fa-map-marker red"></i></a>
                        <a class="btn btn-danger" href='deleteshop.php?owner=<?php echo $row['shopid']; ?>'onclick="Javascript:return window.confirm('Are you sure you want to Delete this record')"><i class="icon_close_alt2"></i></a>
                      </div>    </td>
									 
                                     </tr>
									 
	</tr>
	<?php
		}
	?>
    </div>

    <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>

    </body>
    </html>